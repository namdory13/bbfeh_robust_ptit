#!/bin/bash

if [ ! -d /home/ubuntu/audio_samples ]; then
    mkdir -p /home/ubuntu/audio_samples
fi

if [ ! -f /home/ubuntu/audio_samples/secret.wav ]; then
    python3 /home/ubuntu/.local/bin/make_secret.py
fi

cp /home/ubuntu/.local/bin/detector.py /home/ubuntu/detector.py 2>/dev/null || true
