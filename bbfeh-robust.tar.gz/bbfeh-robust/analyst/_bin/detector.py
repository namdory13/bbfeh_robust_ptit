#!/usr/bin/env python3
import sys
import numpy as np
import soundfile as sf

def corr(x, d):
    x = x - np.mean(x)
    a = x[:-d]
    b = x[d:]
    return abs(np.sum(a*b) / np.sqrt(np.sum(a*a) * np.sum(b*b)))

def detect(path):
    x, sr = sf.read(path)

    if len(x.shape) > 1:
        x = x[:, 0]

    d = 180
    c1 = corr(x, d)
    c2 = corr(x, 2*d)

    if c1 > 0.08 and c2 > 0.035:
        return "DETECTED"
    else:
        return "FAILED"

if len(sys.argv) < 2:
    print("Usage: python3 detector.py <wav_file>")
    sys.exit(1)

file_path = sys.argv[1]
status = detect(file_path)

print(f"{file_path}: {status}")
