#!/usr/bin/env python3
import numpy as np
import soundfile as sf
import os

SR = 44100
DURATION = 5
N = SR * DURATION
OUT = "/home/ubuntu/audio_samples"

os.makedirs(OUT, exist_ok=True)
np.random.seed(10)

def make_cover():
    x = np.random.randn(N).astype(np.float32)
    x = np.convolve(x, np.ones(32)/32, mode="same")
    x = x / np.max(np.abs(x)) * 0.45
    return x.astype(np.float32)

def bbfeh_embed(x, delay=180, alpha=0.75):
    y = x.copy()
    y[delay:] += alpha * x[:-delay]
    y[:-delay] -= alpha * x[delay:]
    y[2*delay:] += (alpha / 2) * x[:-2*delay]
    return np.clip(y, -1, 1).astype(np.float32)

x = make_cover()
y = bbfeh_embed(x, delay=180, alpha=0.75)

sf.write(f"{OUT}/secret.wav", y, SR)

print("Created /home/ubuntu/audio_samples/secret.wav")
