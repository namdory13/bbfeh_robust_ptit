# Lab 3 — Robustness & Attack Against BBFEH

## Mục tiêu

Đánh giá khả năng chịu tấn công của kỹ thuật Bipolar Backward-Forward Echo Hiding.

## File được cung cấp

File chính:

```bash
audio_samples/secret.wav
